package com.buaa.mooc.entity;

public class TeacherCourse {
	private TeacherCoursePK pk;

	public TeacherCoursePK getPk() {
		return pk;
	}

	public void setPk(TeacherCoursePK pk) {
		this.pk = pk;
	}
}
