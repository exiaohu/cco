package com.buaa.mooc.entity;

/**
 * Created by huxia on 2017/6/28.
 */
public interface User {
}
