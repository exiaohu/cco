package com.buaa.mooc.entity;

public class StudentCourse {

	private StudentCoursePK pk;
	private Double score;
	
	public StudentCoursePK getPk() {
		return pk;
	}
	public void setPk(StudentCoursePK ipk) {
		this.pk = ipk;
	}
	public Double getScore() {
		return score;
	}
	public void setScore(Double score) {
		this.score = score;
	}
	
	
}
